# Emotional Infrastructure™ — Consent Token Protocol (CTP) v0.1

Cryptographically enforced, revocable consent for emotional/behavioral data processing.

This repository contains:
- **docs/** – Technical Validation Brief, metrics appendix, and key rotation runbook
- **openapi/** – OpenAPI 3.1 spec for `/issue`, `/introspect`, `/revoke`, `/jwks.json`
- **examples/python-fastapi/** – Reference issuer/validator with SQLite ledger (local HS256)
- **sql/** – Postgres schema (production ledger)
- **infra/** – `docker-compose.yml`, Grafana/Prometheus samples (stubs)
- **jwks/** – JWKS endpoint samples
- **LICENSE** – Apache 2.0 by default (change as desired)

> **Security note:** The demo uses HS256 for local runs. For production, use ES256 with a cloud KMS/HSM and publish a JWKS endpoint. See `docs/Appendix_C_Key_Rotation_Runbook.md`.

## Quickstart (Local)
```bash
# 1) Run the demo API
cd examples/python-fastapi
pip install -r requirements.txt
uvicorn server:app --reload

# 2) Issue a token
curl -s http://127.0.0.1:8000/issue -H 'Content-Type: application/json'   -d '{"ts":"2025-11-09T20:17:00Z","channel":"voice","features":["tone","sentiment"],"processor":"svc://cx-ai/v1","purpose":"customer_retention","retention":"session_only","jurisdiction":"US-KY","ui_copy_id":"consent-modal-2025-11-01#en-US"}'

# 3) Validate/process (replace $TOKEN and keep context identical)
curl -s http://127.0.0.1:8000/process   -H "Authorization: Bearer $TOKEN"   -H 'X-Context: {"ts":"2025-11-09T20:17:00Z","channel":"voice","features":["tone","sentiment"],"processor":"svc://cx-ai/v1","purpose":"customer_retention","retention":"session_only","jurisdiction":"US-KY","ui_copy_id":"consent-modal-2025-11-01#en-US"}'

# 4) Revoke
curl -s http://127.0.0.1:8000/revoke -H 'Content-Type: application/json'   -d '{"jti":"<paste-jti>","reason":"user_revoked"}'
```

## Production Checklist
- ES256 with KMS/HSM; public **JWKS** served at `/.well-known/jwks.json`
- **Push revocation** (SSE/WebSocket) + 5s polling fallback
- Postgres ledger with **hot/warm/cold** tiers + weekly **Merkle anchoring**
- **Prometheus/Grafana** SLOs (see Appendix B)
- **WCAG AA** consent UI; GDPR Art.7 mapping

---
© 2025 Emotional Infrastructure™, Brittany Wright
