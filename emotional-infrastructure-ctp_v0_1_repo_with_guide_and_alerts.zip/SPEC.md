# Consent Token Protocol (CTP) — v0.1 SPEC (Developer-Focused)

This SPEC defines the token claims, validation workflow, revocation, and ledger schema.
For a narrative plus validation results, see `docs/CTP_Validation_Brief.md`.

## Token
- JWT (ES256 recommended; HS256 only for local dev)
- Claims: `iss, aud, sub, iat, exp, jti, scope[], purpose, context_hash, policy_uri, consent_level, consent_version`

## Validation Steps
1. Verify signature via JWKS
2. Check `exp`, `iat` drift ≤ 60s
3. Match `aud`
4. Check revocation (CRL or introspection)
5. Enforce `scope` and `purpose`
6. Recompute and compare `context_hash`
7. Append ledger event

See OpenAPI in `openapi/ctp-api.yaml` for endpoints and schemas.
