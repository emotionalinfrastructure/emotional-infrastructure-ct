# Consent Token Protocol (CTP) — v0.1

Technical specification defining the structure, lifecycle, and validation workflow for short-lived, cryptographically verifiable consent tokens used in emotionally intelligent systems.
For full details, see the accompanying Technical Validation Brief.